====================================================================
GREEN INDIA PRIVATE LIMITED — WORDPRESS, ELEMENTOR & WOOCOMMERCE
ZERO-CODING IMPORT & SETUP GUIDE
====================================================================

IMPORTANT — WHICH ZIP FILE TO UPLOAD WHERE:
1) Appearance > Themes > Add New > Upload Theme:
   Upload ONLY "green-india-theme.zip" (contains style.css, header.php, footer.php, functions.php, woocommerce.php, and built-in Elementor + WooCommerce engine).
   DO NOT upload the master bundle zip directly into Appearance > Themes, or WordPress will say "style.css is missing". Unzip the master bundle first and upload "green-india-theme.zip".

2) Plugins > Add New > Upload Plugin (Optional if using another theme like Hello Elementor):
   Upload "green-india-woo-elementor.zip" for the Elementor widgets & WooCommerce Manager inside any theme.

--------------------------------------------------------------------
FASTEST 3-STEP IMPORT (NO CODING REQUIRED)
--------------------------------------------------------------------
STEP 1: Install Required Free Plugins in WordPress
  - Go to Plugins > Add New and install & activate:
    1) WooCommerce
    2) Elementor

STEP 2: Upload & Activate the Green India Theme
  - Go to Appearance > Themes > Add New > Upload Theme
  - Choose "green-india-theme.zip" and click Install Now > Activate.
  (If you prefer keeping Hello Elementor / Astra, upload "green-india-woo-elementor.zip" under Plugins > Add New > Upload Plugin instead.)

STEP 3: Click One-Click Import
  - In WordPress Admin left sidebar, click "Green India Shop".
  - Click the big green button:
    "One-Click Import All Green India Products, Images & Elementor Pages"
  - Done! All 9 images, all WooCommerce products, and all Elementor pages are created automatically.

--------------------------------------------------------------------
HOW TO EDIT IN ELEMENTOR (VISUAL DRAG & DROP — NO CODE)
--------------------------------------------------------------------
- Open any page (Home, Shop, About Us, Carry Bags, etc.) and click "Edit with Elementor".
- Every section, text, button, color, image, and the WooCommerce Shop Grid can be clicked and styled directly in Elementor's visual panel.
- Zero HTML widgets are used anywhere.

--------------------------------------------------------------------
HOW DYNAMIC SHOP UPDATES WORK
--------------------------------------------------------------------
- Go to "Green India Shop" (or WooCommerce > Products):
  - ADD a product -> It automatically appears on the Shop page in the exact same card design!
  - DELETE / TRASH a product -> It is automatically removed from the Shop page!
  - EDIT Stock, Price, Size, Color, Package (kg/pack), or Pieces per kg -> The Shop card and Product Configurator update immediately!
